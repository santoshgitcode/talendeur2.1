<?php
include 'connection.php';

if (isset($_POST['action'])) {
	if ($_POST['action'] == "edu_level_data") {
		$education = $_POST['education'];
        $value = $_POST['edu_value'];
        $q = "insert into eduLevel (edu_level,value) values ('$education','$value')";
        $res = mysqli_query($con,$q);



         if($res){
 	       echo "success";
          }
         else{
          	echo "no";
         }
    	}


    	if ($_POST['action'] == "feild_study_data") {
		$feildname = $_POST['feildname'];
        $value = $_POST['feild_value'];


        $q = "insert into feildofstudy (feild_name,feild_value) values ('$feildname','$value')";
        $res = mysqli_query($con,$q);



         if($res){
 	       echo "success";
          }
         else{
          	echo "no";
         }
    	}



        if ($_POST['action'] == "degree_data") {
        $degreeName = $_POST['degreeName'];
        $feild_id = $_POST['feild_id'];
        $deg_value = $_POST['deg_value'];


        $q = "insert into degreee (deg_name,feild_id,value) values ('$degreeName','$feild_id','$deg_value')";
        $res = mysqli_query($con,$q);



         if($res){
           echo "success";
          }
         else{
            echo "no";
         }
        }


        if ($_POST['action'] == "uni_data") {
        $university_name = $_POST['university_name'];
        $deg_id = $_POST['deg_id'];
        $uni_value = $_POST['uni_value'];


        $q = "insert into university (uni_name,degre_id,uni_value) values ('$university_name','$deg_id','$uni_value')";
        $res = mysqli_query($con,$q);



         if($res){
           echo "success";
          }
         else{
            echo "no";
         }
        }
}


?>