<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<title>Talendure</title>
	<link rel="stylesheet" type="text/css" href="style/style1.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
	<div class="main_container">
		<div class="top_nav">
			<div class="logo">
				<img src="image/logo.png">

			</div>
			
				<ul class="top_navigation">
					<li><a href="#">OUR STORY</a></li>
					<li><a href="#">INSIGHTS</a></li>
					<li><a href="#">GET IN TOUCH</a></li>
					<li><a href="login.php" class="login">Login</a></li>
				</ul>
		</div>

		<div class="about">
			<h2 class="display-2 mb-1 talendure_heading">Welcome To Talendeur</h2>
			<p class="talendure_para">Talendeur is a reimagined talent engagement platform that provides an inclusive environment for talent to continuously thrive throughout their professional lifecycle leading to the creation of a high quality, diverse workforce of today and future.</p>

 

<p class="talendure_para">Talendeur helps individuals to discover and develop their true potential, supporting them in their learning and up-skilling needs and provide exciting opportunities to experience an ever growing quality of career and satisfying sense of achievement.</p>
  <a href="Register.php"><button type="button" class="btn btn-info btn-lg">Get Started</button></a>





		</div>
	</div>
</body>
</html>