<?php
session_start();
if (isset($_SESSION["fname"])) {

?>


<!DOCTYPE html>
<html>
<head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Talendure</title>
	<link rel="stylesheet" type="text/css" href="style/home.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>

	<div class="top_nav">
	     <div class="logo">
			<img src="image/logo.png">

		</div>
			
			<ul class="top_navigation">
				<li><a href="#">OUR STORY</a></li>
				<li><a href="#">INSIGHTS</a></li>
				<li><a href="#">GET IN TOUCH</a></li>
				<li><button type="button" class="btn ml-5 logout_btn" onclick="logout_process();">Logout</button></li>
			</ul>
			<div class="menu-btn" id="menu_btn">
                <i class="fa fa-bars bg-dark" id="menubar" aria-hidden="true"></i>
            </div>
	</div>
	<!-- navigation End -->

	<div class="content">
          <div class="headingBx">
               <div class="headingBx-content">
          		<div class="user-info">
          		    <i class="fa fa-user fa-3x" aria-hidden="true"></i>
          		</div>
          		<h3>Hello, <?php echo $_SESSION['fname']; ?></h3>
          	</div>         		
          </div>


          <!-- main Tab -->


          <div class="main_tab">
          	<ul class="nav nav-pills">
                    <li class="active"><a data-toggle="pill" href="#profile">Profile</a></li>
                    <li><a data-toggle="pill" href="#career">Career</a></li>
                    <li><a data-toggle="pill" href="#Talendeur" id="my_score">Talendeur</a></li>
               </ul>
          </div>
           <!-- Tab Content Starts -->
           <div class="tab-content">

           	<!-- Profile -->
               <div id="profile" class="tab-pane fade in active show">
               	<div class="profile_tab">
               		<!-- Sidebar Starts -->
               	<div class="side_progressbar">
                  <ul>
                    <li><a href="#" class="active">Basic Informaation</a></li>
                    <li><a href="#">About Me</a></li>
                    <li><a href="#">Qualification</a></li>
                    <li><a href="#">Skills</a></li>
                    <li><a href="#">Work Experience</a></li>
                    <li><a href="#">Certification</a></li>
                    <li><a href="#">Project And Paper</a></li>
                    <li><a href="#">Accomplishment</a></li>
                    <li><a href="#">Social Information</a></li>
                    <li><a href="#">Contextual Information</a></li>
                    <li><a href="#">Statement Of Truth</a></li>
                  </ul>
                </div>
               	<!-- Sidebar Ends -->
               	<!-- Profile Content Starts -->
                    <div class="profile_content">
                    	<div class="basic_info_content" id="first_basic_info">
                  	<div class="bsic_info">
                  		<i class="fa fa-info-circle"></i> <p class="bsic_info_para">Talendeur aims at promoting equality diversity and inclusion during the selecion process.We want the talent to be screened for one's skill, capabilities and personalities.Hence we don't share the following basic information with the employees for the registration of your intrest to enable fair screening through this platform. We would share these information after the mutual registration of intrest from both the talent and organisation.</p>
                  	</div>

                  	<div class="basic_info_form">
                  		<form id="basic_info" name="basic_info">
                        <input type="hidden" value="<?php echo $_SESSION['id']?>" name="user_id">
                  			<div class="form-row">
                          <div class="form-group col-md-4">
                            <label for="FName">First Name</label>
                            <input type="text" class="form-control" id="FName" name="fname" placeholder="First Name">
                          </div>
                          <div class="form-group col-md-4">
                            <label for="LName">Last Name</label>
                            <input type="text" class="form-control" id="LName" name="lname" placeholder="Last Name">
                          </div>
                          <div class="form-group col-md-4">
                            <label for="dob">DOB</label>
                            <input type="date" class="form-control" id="dob" name="dob" placeholder="Dob">
                          </div>
                        </div>
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="inputEmail4">Email</label>
                            <input type="email" class="form-control" id="inputEmail4" name="email" placeholder="Email">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="mobilenumber">Mobile</label>
                            <input type="text" class="form-control" id="mobilenumber" name="mobile" placeholder="Mobile">
                          </div>
                        </div>
                        <div class="form-group">
                          <label for="inputAddress">Address</label>
                          <input type="text" class="form-control" id="inputAddress" name="add_one" placeholder="1234 Main St">
                        </div>
                        <div class="form-group">
                          <label for="inputAddress2">Address 2</label>
                         <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor" name="add_two">
                        </div>
                   <div class="form-row">
                     <div class="form-group col-md-6">
                       <label for="inputCity">City</label>
                       <input type="text" class="form-control" id="inputCity" name="city">
                     </div>
                    <div class="form-group col-md-4">
                      <label for="inputState">State</label>
                      <select id="inputState" class="form-control" name="state">
                            <option selected>Choose...</option>
                            <option value="Andhra Pradesh">Andhra Pradesh</option>
                            <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                            <option value="Assam">Assam</option>
                            <option value="Bihar">Bihar</option>
                            <option value="Chhattisgarh">Chhattisgarh</option>
                            <option value="Goa">Goa</option>
                            <option value="Gujarat">Gujarat</option>
                            <option value="Haryana">Haryana</option>
                            <option value="Haryana">Haryana</option>
                            <option value="Jharkhand">Jharkhand</option>
                            <option value="Karnataka">Karnataka</option>
                            <option value="Kerala">Kerala</option>
                            <option value="Madhya Pradesh">Madhya Pradesh</option>
                            <option value="Maharashtra">Maharashtra</option>
                            <option value="Manipur">Manipur</option>
                            <option value="Meghalaya">Meghalaya</option>
                            <option value="Mizoram">Mizoram</option>
                            <option value="Nagaland">Nagaland</option>
                            <option value="Odisha">Odisha</option>
                            <option value="Punjab">Punjab</option>
                            <option value="Rajasthan">Rajasthan</option>
                            <option value="Sikkim">Sikkim</option>
                            <option value="Tamil Nadu">Tamil Nadu</option>
                            <option value="Telangana">Telangana</option>
                            <option value="Tripura">Tripura</option>
                            <option value="Uttar Pradesh">Uttar Pradesh</option>
                            <option value="Uttarakhand">Uttarakhand</option>
                            <option value="West Bengal">West Bengal</option>
                            <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                            <option value="Chandigarh">Chandigarh</option>
                            <option value="Dadra and Nagar Haveli and Daman and Diu">Dadra and Nagar Haveli and Daman and Diu</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                            <option value="Ladakh">Ladakh</option>
                            <option value="Lakshadweep">Lakshadweep</option>
                            <option value="Puducherry">Puducherry</option>
                       </select>
                      </div>
                    <div class="form-group col-md-2">
                       <label for="inputZip">Zip</label>
                      <input type="text" class="form-control" name="zip" id="inputZip">
                     </div>
                </div>
                  <button type="button" class="btn btn-primary" id="basic_info_submit">Submit</button>
              </form>
         	</div>
        </div>

           <!-- About Form -->
        <div class="basic_info_content about_me" id="second_about_me">
                    <div class="bsic_info">
                      <i class="fa fa-info-circle"></i> <p class="bsic_info_para">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                    </div>

                    <div class="basic_info_form">
                      <form id="about_me_form" name="about_me_form">
                        <input type="hidden" value="<?php echo $_SESSION['id']?>" name="user_id">
                        <div class="form-row">
                          <div class="form-group col-md-12">
                            <label for="aboutme">About Me</label>
                            <textarea rows="4" cols="150" class="form-control" id="aboutme" name="aboutme" placeholder="About Me.."></textarea>
                          </div>
                        </div>
                  <button type="button" class="btn btn-primary" id="about_me_submit">Submit</button>
              </form>
          </div>
        </div>

           <!-- Qualification -->

        <div class="basic_info_content qualification_form" id="third_qualification">
                    <div class="bsic_info">
                      <i class="fa fa-info-circle"></i> <p class="bsic_info_para">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                    </div>

                    <div class="qualification">
                      <div class="btnBx">

                      <button type="button" data-toggle="modal" data-target="#academic_modal" class="btn_academic"><i class="fa fa-plus-circle fa-2x"></i></button>
                      </div>
                      <h4 class="text-center">Add Educational Qualification</h4>

                     
                   </div>

                   <button type="button" class="btn next" id="third_next">Next</button>
        </div>




        <!-- Educational Qualification display -->

        <div class="basic_info_content qualification_display" id="fourth_qualification">
                    <div class="edu_qua_head">
                      <div>
                        <h2>Educational Qualification</h2>
                      </div>
                      <div class="edu_add">
                        <div><p class="edu_para">Add</p></div>
                        <div><i class="fa fa-plus-circle text-danger"></i></div>
                      </div>
                    </div>

                    <div class="row qualificationBx">
                      <div class="col-md-5 m-auto qualification_card p-3">
                        <div class="row">
                          <div class="col-9">
                          <h5>Bachelor Of Ats</h5>
                          <p>Texas University</p>
                          <p><span>2010</span>-<span>2013</span></p>
                        </div>
                        <div class="col-3">
                          <i class="fa fa-edit mr-3"></i>
                          <i class="fa fa-trash"></i>
                        </div>
                        </div>
                        
                      </div>
                      <!-- <div class="qualification_card col-md-5 m-auto p-3">
                        <div class="row">
                          <div class="col-9">
                          <h5>Bachelor Of Ats</h5>
                          <p>Texas University</p>
                          <p><span>2010</span>-<span>2013</span></p>
                        </div>
                        <div class="col-3">
                          <i class="fa fa-edit mr-3"></i>
                          <i class="fa fa-trash"></i>
                        </div>
                        </div>
                      </div> -->
                    </div>

                    <div class="btnBx mt-5 ml-auto mr-auto">
                      <button type="button" class="btn next align-middle" id="fouth_next">Next</button>
                    </div>
        </div>


        <!-- Add new skill Start -->

        <div class="basic_info_content add_skill" id="add_skill">
                    <div class="add_skill_heading">
                      <div>
                        <h2>Add New Skill</h2>
                      </div>
                    </div>
                    <div class="add_a_skill">


                       <form id="skill_form" name="skill_form">
                         <div class="form-row">
                          <div class="form-group col-md-9">
                            <input type="text" class="form-control" name="skill" placeholder="Add a Skill">
                          </div>
                          <div class="form-group col-md-3">
                            <button type="button" class="skill_btn text-center"><p>Add <span><i class="fa fa-plus-circle ml-2"></i></span></p></button>
                          </div>
                        </div>
                      </form>
                    </div>

                    <div class="your_skill mt-5">
                      <div class="add_skill_heading">
                      <div>
                        <h2>Skills</h2>
                      </div>
                    </div>

                    <div class="row justify-content-around mt-2">
                          <div class="col-md-5 col-sm-12 your_skill_display">

                            <div class="row justify-content-between pt-2">
                              <div class="col-9"><p class="text-muted">Design Thinking</p></div>
                              <div class="col-3"><p><span><i class="fa fa-edit"></i></span><span><i class="fa fa-trash ml-3"></i></span></p></div>
                            </div>
                            
                          </div>
                          <div class="col-md-5 your_skill_display">
                            <div class="row justify-content-between pt-2">
                              <div class="col-9"><p class="text-muted">Design Thinking</p></div>
                              <div class="col-3"><p><span><i class="fa fa-edit"></i></span><span><i class="fa fa-trash ml-3"></i></span></p></div>
                            </div>
                          </div>
                     </div>
                    </div>

                    <div class="btnBx mt-5 ml-auto mr-auto">
                      <button type="button" class="btn next align-middle" id="skill_next">Next</button>
                    </div>
        </div>



<!-- Work Experience -->

        <div class="basic_info_content Work_experience" id="Work_experience">
                    <div class="bsic_info">
                      <i class="fa fa-info-circle"></i> <p class="bsic_info_para">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                    </div>

                    <div class="qualification">
                      <div class="btnBx">

                      <button type="button" data-toggle="modal" data-target="#work_modal" class="btn_academic"><i class="fa fa-plus-circle fa-2x"></i></button>
                      </div>
                      <h4 class="text-center">Add Wok Experience</h4>

                     
                   </div>

                   <button type="button" class="btn next" id="Work_next">Next</button>
        </div>


        <!-- Work Experience  Display-->

        <div class="basic_info_content Work_experience_dis" id="Work_experience_dis">
                  

                    <div class="row">
                      <div class="col-6">
                        <h4>work Experience</h4>
                      </div>
                      <div class="col-6">
                        <p class="text-right">Add<span><i class="fa fa-plus-circle ml-2"></i></span></p>
                      </div>
                    </div>

                     <div class="border  mt-4 mb-4">
                       <table class="table table-condensed table-hover">
                          <thead>
                             <tr>
                              <th>Role</th>
                              <th>Organisation</th>
                              <th>Job Type</th>
                              <th>Duration</th>
                              <th></th>
                            </tr>
                         </thead>
                         <tbody>
                          <tr>
                           <td>UI Designer</td>
                           <td>Netsoft Techonology</td>
                           <td>Full Time</td>
                           <td><span>Jul18</span>-<span>Present</span></td>
                           <td><button  class="operation_btn"><i class="fa fa-edit"></i></button> <button class="operation_btn"><i class="fa fa-trash"></i></button></td>
                          </tr>
                          <tr>
                           <td>UI Designer</td>
                           <td>Netsoft Techonology</td>
                           <td>Full Time</td>
                           <td><span>Jul18</span>-<span>Present</span></td>
                           <td><button  class="operation_btn"><i class="fa fa-edit"></i></button> <button class="operation_btn"><i class="fa fa-trash"></i></button></td>
                          </tr>
                          <tr>
                           <td>UI Designer</td>
                           <td>Netsoft Techonology</td>
                           <td>Full Time</td>
                           <td><span>Jul18</span>-<span>Present</span></td>
                           <td><button  class="operation_btn"><i class="fa fa-edit"></i></button> <button class="operation_btn"><i class="fa fa-trash"></i></button></td>
                          </tr>
                          
                    </tbody>
                  </table>
                     </div>

                     <div class="covering_letter mt-4 mb-3">
                       <h4>Covering Letter</h4>
                       <div class="covering_letter_Bx border p-1">
                         <p class="text-justify">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                       </div>
                     </div>

                   <button type="button" class="btn next" id="Work_dis_next">Next</button>
        </div>


        <!-- Certificate -->

        <div class="basic_info_content certificate" id="certificate">
                    <div class="bsic_info">
                      <i class="fa fa-info-circle"></i> <p class="bsic_info_para">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                    </div>

                    <div class="qualification">
                      <div class="btnBx">

                      <button type="button" data-toggle="modal" data-target="#certificate_modal" class="btn_academic"><i class="fa fa-plus-circle fa-2x"></i></button>
                      </div>
                      <h4 class="text-center">Add Certificate</h4>

                     
                   </div>

                   <button type="button" class="btn next" id="certificate_next">Next</button>
        </div>



        <!-- Csertificate  Display-->

        <div class="basic_info_content certificate_dis" id="certificate_dis">
                  

                    <div class="row">
                      <div class="col-6">
                        <h4>Licenses, Courses & Certifications</h4>
                      </div>
                      <div class="col-6">
                        <p class="text-right">Add<span><i class="fa fa-plus-circle ml-2"></i></span></p>
                      </div>
                    </div>

                     <div class="border  mt-4 mb-4">
                       <table class="table table-condensed table-hover">
                          <thead>
                             <tr>
                              <th>Name</th>
                              <th>Organisation</th>
                              <th>Year</th>
                              <th></th>
                            </tr>
                         </thead>
                         <tbody>
                          <tr>
                           <td>Information Visualization</td>
                           <td>Netsoft Techonology</td>
                           <td>2018</td>
                           <td><button  class="operation_btn"><i class="fa fa-edit"></i></button> <button class="operation_btn"><i class="fa fa-trash"></i></button></td>
                          </tr>
                          
                    </tbody>
                  </table>
                     </div>

                   <button type="button" class="btn next" id="certificate_dis_next">Next</button>
        </div>


        



        <!-- Project And Papers -->

        <div class="basic_info_content project_paper" id="project_paper">
                    <div class="bsic_info">
                      <i class="fa fa-info-circle"></i> <p class="bsic_info_para">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                    </div>

                    <div class="qualification mt-5 mb-5">
                      <div class="row">
                        <div class="col-6">
                          <div class="btnBx">
                      <button type="button" data-toggle="modal" data-target="#project" class="btn_academic"><i class="fa fa-plus-circle fa-2x"></i></button>
                      </div>
                      <p class="text-center">Add Project</p>
                        </div>
                        <div class="col-6">
                          <div class="btnBx">
                      <button type="button" data-toggle="modal" data-target="#papers" class="btn_academic"><i class="fa fa-plus-circle fa-2x"></i></button>
                      </div>
                      <p class="text-center">Add Papers & Publication</p>
                        </div>
                      </div>

                     
                   </div>

                   <button type="button" class="btn next" id="project_next">Next</button>
        </div>


        <!-- Project And Papers Display  Display-->

        <div class="basic_info_content project_paper_display" id="project_paper_display">
                  

                    <div class="project_display">
                      <div class="row">
                      <div class="col-6">
                        <h4>Project</h4>
                      </div>
                      <div class="col-6">
                        <p class="text-right">Add<span><i class="fa fa-plus-circle ml-2"></i></span></p>
                      </div>
                    </div>

                     <div class="border  mt-1 mb-4">
                       <table class="table table-condensed table-hover">
                          <thead>
                             <tr>
                              <th>Title</th>
                              <th>Year</th>
                              <th>Description</th>
                              <th></th>
                            </tr>
                         </thead>
                         <tbody>
                          <tr>
                           <td>Ecommerce Website</td>
                           <td>2018</td>
                           <td>Ecommerce Website that sells health And Beauty Products, Electronics etc</td>
                           <td><button  class="operation_btn"><i class="fa fa-edit"></i></button> <button class="operation_btn"><i class="fa fa-trash"></i></button></td>
                          </tr>
                          
                    </tbody>
                  </table>
                     </div>
                    </div>


                    <div class="paper_display mt-5">
                      <div class="row">
                      <div class="col-6">
                        <h4>Papers And Publications</h4>
                      </div>
                      <div class="col-6">
                        <p class="text-right">Add<span><i class="fa fa-plus-circle ml-2"></i></span></p>
                      </div>
                    </div>

                     <div class="border  mt-1 mb-4">
                       <table class="table table-condensed table-hover">
                          <thead>
                             <tr>
                              <th>Title</th>
                              <th>Year</th>
                              <th>Description</th>
                              <th></th>
                            </tr>
                         </thead>
                         <tbody>
                          <tr>
                           <td>The Freshness of cultural Probes</td>
                           <td>2018</td>
                           <td>Ecommerce Website that sells health And Beauty Products, Electronics etc</td>
                           <td><button  class="operation_btn"><i class="fa fa-edit"></i></button> <button class="operation_btn"><i class="fa fa-trash"></i></button></td>
                          </tr>
                          
                    </tbody>
                  </table>
                     </div>
                    </div>

                   <button type="button" class="btn next" id="project_dis_next">Next</button>
        </div>


        <!-- Achivements And Awards -->
            


            <div class="basic_info_content achivements" id="achivements">
                    <div class="bsic_info">
                      <i class="fa fa-info-circle"></i> <p class="bsic_info_para">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                    </div>

                    <div class="qualification">
                      <div class="btnBx">

                      <button type="button" data-toggle="modal" data-target="#award" class="btn_academic"><i class="fa fa-plus-circle fa-2x"></i></button>
                      </div>
                      <h4 class="text-center">Add Awards</h4>

                     
                   </div>

                   <div class="Add_achivement">
                     <p>Addtional Achivements <span class="ml-2"><i class="fa fa-info-circle"></i></span></p>
                     <div class="add_achiveent_formBx border">
                       <form id="achivement_forrm" name="achivement_forrm">
                         <div class="form-row">
                          <div class="form-group col-md-11">
                            <input type="text" class="form-control" name="achivement_name" placeholder="Add Your Achivements Here">
                          </div>
                          <div class="form-group col-md-1">
                            <button type="button" class="skill_btn text-center"><p>Add <span><i class="fa fa-plus-circle ml-2"></i></span></p></button>
                          </div>
                        </div>
                      </form>
                     </div>
                   </div>

                   <button type="button" class="btn next" id="achivement_next">Next</button>
        </div>     



        <!-- Award And Achivements Display -->

        <div class="basic_info_content award_achivement_display" id="achivement_dis">
                  

                    <div class="award_display">
                      <div class="row">
                      <div class="col-6">
                        <h4>Awards</h4>
                      </div>
                      <div class="col-6">
                        <p class="text-right">Add<span><i class="fa fa-plus-circle ml-2"></i></span></p>
                      </div>
                    </div>

                     <div class="border  mt-1 mb-4">
                       <table class="table table-condensed table-hover">
                          <thead>
                             <tr>
                              <th>Title</th>
                              <th>Year</th>
                              <th>Organistion</th>
                              <th></th>
                            </tr>
                         </thead>
                         <tbody>
                          <tr>
                           <td>Excelent User Experience Award</td>
                           <td>2018</td>
                           <td>IBZ Design Foundation</td>
                           <td><button  class="operation_btn"><i class="fa fa-edit"></i></button> <button class="operation_btn"><i class="fa fa-trash"></i></button></td>
                          </tr>
                          
                    </tbody>
                  </table>
                     </div>
                    </div>


                    <div class="achivements_display mt-5">

                      <div class="award_display">
                      <div class="row">
                      <div class="col-6">
                        <h4>Achivements</h4>
                      </div>
                    </div>

                    <div class=" mb-5">
                      <div class="achivementBx pt-2 pl-5 mb-2">
                        <div class="row">
                        <div class="col-10">
                          <p>Volunteer at kenal water Shed</p>
                        </div>
                        <div class="col-2">
                          <p><span><i class="fa fa-edit"></i></span><span class="ml-4"><i class="fa fa-trash"></i></span></p>
                        </div>
                      </div>
                      </div>
                      <div class="achivementBx pt-2 pl-5 mb-2">
                        <div class="row">
                        <div class="col-10">
                          <p>Volunteer at kenal water Shed</p>
                        </div>
                        <div class="col-2">
                          <p><span><i class="fa fa-edit"></i></span><span class="ml-4"><i class="fa fa-trash"></i></span></p>
                        </div>
                      </div>
                      </div>

                    </div>



                    </div>
                      
                    </div>

                   <button type="button" class="btn next" id="achivement_dis_next">Next</button>
        </div>



        <!-- Social Profile Links -->

        <div class="basic_info_content social_profile" id="social_profile">
                  

                    <div class="award_display">
                      <div class="row">
                      <div class="col-6">
                        <h4>Social Profile Links</h4>
                      </div>
                    </div>
                    </div>

                    <div class="socialBx">
                      <form id="social_form" name="social_form">
            <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="linkdin_profile">Likdin Profile Url</label>
                            <input type="text" name="linkdin_profile" class="form-control">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="git_profile">Git Profile URL</label>
                            <input type="text" name="git_profile" class="form-control">
                          </div>
                        </div>
          </form>
                    </div>

                    <div class="row">
                      <div class="col-6">
                        <h4>Appriciatons/References</h4>
                      </div>
                      <div class="col-6">
                        <p class="text-right">Add<span><i class="fa fa-plus-circle ml-2"></i></span></p>
                      </div>
                    </div>
                    <div class="appriciation_note">
                      <div class="row">
                        <div class="col-10">
                          <p class="text-justify">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                         </div>
                         <div class="col-2"><button  class="operation_btn"><i class="fa fa-edit"></i></button> <button class="operation_btn"><i class="fa fa-trash"></i></button></div>
                      </div>
                    </div>

                    <div class="forums_groups mt-4 mb-4">
                      <div class="row">
                        <div class="col-md-6 forum">
                          <div class="row">
                            <div class="col-10"><p>https://www.redict.com</p></div>
                            <div class="col-2"><button  class="operation_btn"><i class="fa fa-edit"></i></button> <button class="operation_btn"><i class="fa fa-trash"></i></button></div>
                          </div>
                          </div>
                          <div class="col-md-6 forum">
                            <div class="row">
                            <div class="col-10"><p>https://www.redict.com</p></div>
                            <div class="col-2"><button  class="operation_btn"><i class="fa fa-edit"></i></button> <button class="operation_btn"><i class="fa fa-trash"></i></button></div>
                          </div>
                          </div>
                        </div>
                        
                      </div>
                   <button type="button" class="btn next" id="social_next">Next</button>
        </div>


        <!-- T&C Declaration -->

            


            <div class="basic_info_content t_c" id="t_c">
                    <div class="bsic_info">
                      <i class="fa fa-info-circle"></i> <p class="bsic_info_para">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                    </div>

                   <button type="button" class="btn next" id="t_c_next">Next</button>
        </div> 


        <!-- Statment Of Truth -->

        <div class="basic_info_content statment_truth" id="statment_truth">
                    <div class="statment mb-5">
                      <form id="statment_form" name="statment_form">
                        <div class="row">
                          <div class="col-1">
                            <input type="checkbox" name="statment" value="declared" id="statment_check">
                          </div>
                          <div class="col-10">
                        <label for="statment_check">I hereby declare that the information provided is true and correct to the best of my knowledge and belleif in case only information provided provess to be false or incorrect, I shall be responsiable for the consequences.</label>
                            
                          </div>
                        </div>
                        <button type="button" class="btn btn-warning mt-2">Submit</button>
                      </form>
                    </div>
        </div> 





                    </div>
               	</div>
               	
                    <!-- Profile Content Ends -->
            </div>

            <!-- Profile Ends -->

            <!-- QUALIFICATION MODAL -->
            <div class="modal fade" id="academic_modal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        
        <!-- Modal body -->
        <div class="modal-body">
          <form id="academic_form_f" name="academic_form_f">
            <input type="hidden" value="<?php echo $_SESSION['id']?>" name="user_id">
            <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="edu_level">Educational Level<span class="mandetory">*</span></label>
                            <select id="edu_level" name="edu_level" class="form-control">
                              <option value="no">Select Educational Level</option>
                              <option value="High School">High School</option>
                              <option value="Undergraduate">Undergraduate</option>
                              <option value="Graduate 3yr">Graduate 3yr</option>
                              <option value="Graduate 4yr">Graduate 4yr</option>
                              <option value="Post Graduate">Post Graduate</option>
                              <option value="PHD">PHD</option>
                            </select>
                          </div>
                          <div class="form-group col-md-6">
                            <label for="feild_study">Field Of Study<span class="mandetory">*</span></label>
                            <select id="feild_study" class="form-control" name="field_study">
                              <option value="no">Select Field of study</option>
                              <option value="Arts">Arts</option>
                              <option value="Commerce">Commerce</option>
                              <option value="science">Science</option>
                            </select>
                          </div>
                        </div>
              <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="degreee">Degree<span class="mandetory">*</span></label>
                            <select id="degreee" class="form-control" name="degree">
                              <option value="no">Degree</option>
                              <option value="Bachelor of Arts">Bachelor of Arts</option>
                              <option value="Bachelor of Science">Bachelor of Science</option>
                              <option value="Bachelor of Commerce">Bachelor of Commerce</option>
                              <option value="Bachelor of Engg">Bachelor of Engg</option>
                              <option value="BMS/BBA/BBS">BMS/BBA/BBS</option>
                              <option value="Bachelor of Law">Bachelor of Law</option>
                              <option value="Bachelor of Medicine (MBBS)">Bachelor of Medicine (MBBS)</option>
                            </select>
                          </div>
                          <div class="form-group col-md-6">
                            <label for="university">College/University<span class="mandetory">*</span></label>
                            <select id="university" class="form-control" name="university">
                              <!-- <option value="no">University</option>
                              <option value="Indian Institute of Technology Madras">Indian Institute of Technology Madras</option>
                              <option value="Indian Institute of Science">Indian Institute of Science</option>
                              <option value="Indian Institute of Technology Bombay">Indian Institute of Technology Bombay</option>
                              <option value="Indian Institute of Technology Delhi">Indian Institute of Technology Delhi</option>
                              <option value="Indian Institute of Technology Kanpur"> Indian Institute of Technology Kanpur</option>
                              <option value="Indian Institute of Technology Kharagpur">Indian Institute of Technology Kharagpur</option>
                              <option value="Indian Institute of Technology Roorkee"> Indian Institute of Technology Roorkee</option>
                              <option value="Indian Institute of Technology Guwahati"> Indian Institute of Technology Guwahati</option>
                              <option value="Jawaharlal Nehru University">Jawaharlal Nehru University</option>
                              <option value="Banaras Hindu University">Banaras Hindu University</option>
                              <option value="Calcutta University">Calcutta University</option>
                              <option value="Jamia Millia Islamia">Jamia Millia Islamia</option> -->
                            </select>
                          </div>
                        </div>

                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="grade">Grade<span class="mandetory">*</span></label>
                            <select id="grade" name="grade" class="form-control">
                              <option value="no">Select Grade</option>
                              <option value="First Division">First Division</option>
                              <option value="First Division with distinction">First Division with distinction</option>
                              <option value="Merit/topper">Merit/topper</option>
                              <option value="Below First Division">Below First Division</option>
                              
                            </select>
                          </div>
                        </div> 


                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="month">Form<span class="mandetory">*</span></label>
                            <select id="month" class="form-control col-5" name="form_month">
                              <option value="jan">Jan</option>
                              <option value="feb">Feb</option>
                              <option value="mar">Mar</option>
                              <option value="april">April</option>
                              <option value="may">May</option>
                              <option value="jun">Jun</option>
                              <option value="jul">Jul</option>
                              <option value="aug">Aug</option>
                              <option value="sep">Sep</option>
                              <option value="oct">Oct</option>
                              <option value="nov">Nov</option>
                              <option value="dec">Dec</option>
                            </select>
                            <select id="form_year" class="form-control col-5" name="form_year">
                              <option value="1980">1980</option>
                              <option value="1981">1981</option>
                              <option value="1982">1982</option>
                              <option value="1983">1983</option>
                              <option value="1984">1984</option>
                              <option value="1985">1985</option>
                              <option value="1986">1986</option>
                              <option value="1987">1987</option>
                              <option value="1988">1988</option>
                              <option value="1989">1989</option>
                              <option value="1990">1990</option>
                              <option value="1991">1991</option>
                              <option value="1992">1992</option>
                              <option value="1993">1993</option>
                              <option value="1994">1994</option>
                              <option value="1995">1995</option>
                              <option value="1996">1996</option>
                              <option value="1997">1997</option>
                              <option value="1998">1998</option>
                              <option value="1999">1999</option>
                              <option value="2000">2000</option>
                              <option value="2001">2001</option>
                              <option value="2002">2002</option>
                              <option value="2003">2003</option>
                              <option value="2004">2004</option>
                              <option value="2005">2005</option>
                              <option value="2006">2006</option>
                              <option value="2007">2007</option>
                              <option value="2008">2008</option>
                              <option value="2009">2009</option>
                              <option value="2010">2010</option>
                              <option value="2011">2011</option>
                              <option value="2012">2012</option>
                              <option value="2013">2013</option>
                              <option value="2014">2014</option>
                              <option value="2015">2015</option>
                              <option value="2016">2016</option>
                              <option value="2017">2017</option>
                              <option value="2018">2018</option>
                              <option value="2019">2019</option>
                              <option value="2020">2020</option>
                              <option value="2021">2021</option>
                              <option value="2022">2022</option>
                            </select>

                          </div>
                          <div class="form-group col-md-6">
                            <label for="month">To<span class="mandetory">*</span></label>
                            <select id="month" class="form-control col-5" name="to_month">
                              <option value="jan">Jan</option>
                              <option value="feb">Feb</option>
                              <option value="mar">Mar</option>
                              <option value="april">April</option>
                              <option value="may">May</option>
                              <option value="jun">Jun</option>
                              <option value="jul">Jul</option>
                              <option value="aug">Aug</option>
                              <option value="sep">Sep</option>
                              <option value="oct">Oct</option>
                              <option value="nov">Nov</option>
                              <option value="dec">Dec</option>
                            </select>
                             <select id="to_year" class="form-control col-5" name="to_year">
                              <option value="1980">1980</option>
                              <option value="1981">1981</option>
                              <option value="1982">1982</option>
                              <option value="1983">1983</option>
                              <option value="1984">1984</option>
                              <option value="1985">1985</option>
                              <option value="1986">1986</option>
                              <option value="1987">1987</option>
                              <option value="1988">1988</option>
                              <option value="1989">1989</option>
                              <option value="1990">1990</option>
                              <option value="1991">1991</option>
                              <option value="1992">1992</option>
                              <option value="1993">1993</option>
                              <option value="1994">1994</option>
                              <option value="1995">1995</option>
                              <option value="1996">1996</option>
                              <option value="1997">1997</option>
                              <option value="1998">1998</option>
                              <option value="1999">1999</option>
                              <option value="2000">2000</option>
                              <option value="2001">2001</option>
                              <option value="2002">2002</option>
                              <option value="2003">2003</option>
                              <option value="2004">2004</option>
                              <option value="2005">2005</option>
                              <option value="2006">2006</option>
                              <option value="2007">2007</option>
                              <option value="2008">2008</option>
                              <option value="2009">2009</option>
                              <option value="2010">2010</option>
                              <option value="2011">2011</option>
                              <option value="2012">2012</option>
                              <option value="2013">2013</option>
                              <option value="2014">2014</option>
                              <option value="2015">2015</option>
                              <option value="2016">2016</option>
                              <option value="2017">2017</option>
                              <option value="2018">2018</option>
                              <option value="2019">2019</option>
                              <option value="2020">2020</option>
                              <option value="2021">2021</option>
                              <option value="2022">2022</option>
                            </select>
                          </div>
                        </div> 
                        

            <button type="button" class="btn btn-warning" onclick="return academic_data();" data-dismiss="modal">Submit</button>
          </form>
        </div>
        
      </div>
    </div>
  </div>



      <!-- QUALIFICATION MODAL -->
            <div class="modal fade" id="work_modal">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">

        <div class="modal-header">
        <h4 class="modal-title">Work Experience</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
        
        <!-- Modal body -->
        <div class="modal-body">
          <form id="academic_form" name="academic_form">
            <div class="form-row">
                          <div class="form-group col-md-3">
                            <label>Job Title</label>
                            <input type="text" placeholder="Senior UI Designer" name="job_title" class="form-control">
                          </div>
                          <div class="form-group col-md-3">
                            <label>Job Type</label>
                            <select class="form-control" name="job_type">
                              <option value="full time">Full Time</option>
                              <option value="part time">Part Time</option>
                            </select>
                          </div>
                          <div class="form-group col-md-3">
                            <label>Company</label>
                            <input type="text" placeholder="Netsoft Techonology" name="company" class="form-control">
                          </div>
                          
                          <div class="form-group col-md-3">
                            <label>Loaction</label>
                            <input type="text" placeholder="Manchester" name="location" class="form-control">
                          </div>
                        
                        </div>


                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <div class="row">
                              <div class="col-6">
                                <label>Start Date</label>
                                <div class="row">
                                  <div class="col-6">
                                    <select class="form-control" name="start_month">
                                      <option value="jan">Jan</option>
                                      <option value="feb">Feb</option>
                                     </select>
                                  </div>
                                  <div class="col-6">
                                    <select class="form-control" name="start_year">
                                      <option value="1999">1999</option>
                                      <option value="2000">2000</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                              <div class="col-6">
                                <label>End Date</label>
                                <div class="row">
                                  <div class="col-6">
                                    <select class="form-control" name="end_month">
                                      <option value="jan">Jan</option>
                                      <option value="feb">Feb</option>
                                     </select>
                                  </div>
                                  <div class="col-6">
                                    <select class="form-control" name="end_year">
                                      <option value="1999">1999</option>
                                      <option value="2000">2000</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-md-6 pt-3">
                            <input type="checkbox" value="presently working" name="present_work" id="present_working"><label for="present_working" class="ml-2">Presently Working Here</label>
                          </div>
                        
                        </div>


                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <p>Description</p>
                            <textarea class="form-control"></textarea>
                          </div>
                          <div class="form-group col-md-6">
                            <p>Responsibilities</p>
                            <textarea class="form-control"></textarea>
                          </div>
                          </div>
                      <div class="form-row">
                        <div class="form-group col-md-6">
                            <p>Achivements</p>
                            <textarea class="form-control"></textarea>
                          </div>
                      </div>
                        

            <button type="button" class="btn btn-warning" onclick="return academic_data();" data-dismiss="modal">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>
      

      <!-- Certificate Modal -->

      <div class="modal fade" id="certificate_modal">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">

        <div class="modal-header">
        <h4 class="modal-title"></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
        
        <!-- Modal body -->
        <div class="modal-body">
          <form id="certificate_form" name="certificate_form">
            <input type="hidden" value="<?php echo $_SESSION['id']?>" name="user_id">
            <div class="form-row">
                          <div class="form-group col-md-6">
                            <label>Name</label>
                            <input type="text" placeholder="Certificate Name" id="certificate_name" name="certificate_name" class="form-control">
                          </div>
                          <div class="form-group col-md-6">
                            <label>Isuing Organisationn</label>
                            <input type="text" placeholder="Organisation Name" name="org_name" id="org_name" class="form-control">
                          </div>
                        
                        </div>


                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <label>Issued Date</label>
                            <div class="row">

                              <div class="col-6">
                                
                                
                                  
                                    <select class="form-control" name="issued_month">
                                      <option value="jan">Jan</option>
                                      <option value="feb">Feb</option>
                                     </select>
                                  
                                
                              </div>
                              <div class="col-6">
                                  
                                    <select class="form-control" name="issued_yr" id="issued_yr">
                                      <option value="1999">1999</option>
                                      <option value="2000">2000</option>
                                    </select>
                                  
                                
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-md-6">
                             <label>Expiration Date</label>
                            <div class="row">

                              <div class="col-6">  
                                    <select class="form-control" name="exp_month">
                                      <option value="">Select month</option>
                                      <option value="jan">Jan</option>
                                      <option value="feb">Feb</option>
                                     </select>
                              </div>
                              <div class="col-6">
                                    <select class="form-control" name="exp_yr" id="exp_yr">
                                      <option value="">Select Year</option>
                                      <option value="1999">1999</option>
                                      <option value="2000">2000</option>
                                    </select>
                              </div>
                            </div>
                          </div>
                        
                        </div>



                        <div class="form-row ml-3">
                          <input type="checkbox" value="No Expiration Date" name="no_exp_date" id="no_exp_date"><label for="no_exp_date" class="ml-4">No Expiration Date</label>
                        </div>


                        <div class="form-row">
                          <div class="form-group col-12">
                            <p>Certificate URL</p>
                            <input type="text" placeholder="https://www.talendure.com" name="c_url" class="form-control">
                          </div>
                          </div>
                      <div class="form-row">
                        <div class="form-group col-md-12">
                            <p>Description</p>
                            <textarea class="form-control" placeholder="description" name="c_desc"></textarea>
                          </div>
                      </div>
                        

            <button type="button" class="btn btn-warning" onclick="return certificate_data();" data-dismiss="modal">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>



  <!-- Project Modal -->
            <div class="modal fade" id="project">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">

        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
        
        <!-- Modal body -->
        <div class="modal-body">
          <form id="academic_form" name="academic_form">
            <div class="form-row">
                          <div class="form-group col-12">
                            <label>Project Name</label>
                            <input type="text" placeholder="Project Name" name="project_name" class="form-control">
                          </div>
                        
                        </div>


                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <label>Start Date</label>
                            <div class="row">

                              <div class="col-6">
                                
                                
                                  
                                    <select class="form-control" name="start_month">
                                      <option value="jan">Jan</option>
                                      <option value="feb">Feb</option>
                                     </select>
                                  
                                
                              </div>
                              <div class="col-6">
                                  
                                    <select class="form-control" name="start_year">
                                      <option value="1999">1999</option>
                                      <option value="2000">2000</option>
                                    </select>
                                  
                                
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-md-6">
                             <label>End Date</label>
                            <div class="row">

                              <div class="col-6">  
                                    <select class="form-control" name="end_month">
                                      <option value="jan">Jan</option>
                                      <option value="feb">Feb</option>
                                     </select>
                              </div>
                              <div class="col-6">
                                    <select class="form-control" name="end_year">
                                      <option value="1999">1999</option>
                                      <option value="2000">2000</option>
                                    </select>
                              </div>
                            </div>
                          </div>
                        
                        </div>


                        <div class="form-row">
                          <div class="form-group col-12">
                            <p>Project URL</p>
                            <input type="text" placeholder="https://www.talendure.com" name="project_url" class="form-control">
                          </div>
                          </div>
                      <div class="form-row">
                        <div class="form-group col-md-12">
                            <p>Description</p>
                            <textarea class="form-control" placeholder="description"></textarea>
                          </div>
                      </div>
                        

            <button type="button" class="btn btn-warning" onclick="return academic_data();" data-dismiss="modal">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>


  <!-- Paper And Publication Modal -->
            <div class="modal fade" id="papers">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">

        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
        
        <!-- Modal body -->
        <div class="modal-body">
          <form id="paper_form" name="paper_form">
            <div class="form-row">
                          <div class="form-group col-md-6">
                            <label>Title</label>
                            <input type="text" placeholder="Title" name="paper_title" class="form-control">
                          </div>
                          <div class="form-group col-md-6">
                            <div class="col-6">
                              <label>Year</label>
                              <select class="form-control" name="paper_year">
                                      <option value="1999">1999</option>
                                      <option value="2000">2000</option>
                                    </select>

                            </div>
                          </div>
                        
                        </div>


                        <div class="form-row">
                          <div class="form-group col-12">
                            <p>Project URL</p>
                            <input type="text" placeholder="https://www.talendure.com" name="paper_url" class="form-control">
                          </div>
                          </div>
                      <div class="form-row">
                        <div class="form-group col-md-12">
                            <p>Description</p>
                            <textarea class="form-control" placeholder="description" name="description"></textarea>
                          </div>
                      </div>
                        

            <button type="button" class="btn btn-warning" onclick="return academic_data();" data-dismiss="modal">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>


  <!-- Award Modal -->

      <div class="modal fade" id="award">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">

        <div class="modal-header">
        <h4 class="modal-title"></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
        
        <!-- Modal body -->
        <div class="modal-body">
          <form id="award_form" name="award_form">
            <div class="form-row">
                          <div class="form-group col-md-6">
                            <label>Title</label>
                            <input type="text" placeholder="Title Of the Award" name="award_title" class="form-control">
                          </div>
                          <div class="form-group col-md-6">
                            <label>Issuing Organisationn</label>
                            <input type="text" placeholder="Organisationn Name" name="org_name" class="form-control">
                          </div>
                        
                        </div>


                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <label>Date awarded</label>
                            <div class="row">

                              <div class="col-6">
                                
                                
                                  
                                    <select class="form-control" name="start_month">
                                      <option value="jan">Jan</option>
                                      <option value="feb">Feb</option>
                                     </select>
                                  
                                
                              </div>
                              <div class="col-6">
                                  
                                    <select class="form-control" name="start_year">
                                      <option value="1999">1999</option>
                                      <option value="2000">2000</option>
                                    </select>
                                  
                                
                              </div>
                            </div>
                          </div>
                        
                        </div>
                      <div class="form-row">
                        <div class="form-group col-md-12">
                            <p>Description</p>
                            <textarea class="form-control" placeholder="description"></textarea>
                          </div>
                      </div>
                        

            <button type="button" class="btn btn-warning" onclick="return academic_data();" data-dismiss="modal">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>



            <div id="career" class="tab-pane fade">
              <h3>Career</h3>
              <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
         <div id="Talendeur" class="tab-pane fade">
            <div class="Talendeur_score">
              <div class="row">
                <div class="col-md-6 m-auto">
                  <div class="score_circle m-auto"><span>4</span></div>
                  <div class="score_rating">
                    <div class="rating">
                      <i class="fa fa-star fa-2x" aria-hidden="true"></i>
                      <i class="fa fa-star fa-2x" aria-hidden="true"></i>
                      <i class="fa fa-star fa-2x" aria-hidden="true"></i>
                       <i class="fa fa-star fa-2x" aria-hidden="true"></i>
                      <i class="fa fa-star fa-2x gray" aria-hidden="true"></i>
                   </div>
                   <h2>Talendeur Score</h2>
          
        </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="progress_bar_graph">
                     
                          <label>Knowledge And Qualification</label>                    
                         <div class="progress">
                        <div class="progress-bar" id="qualification_progressbar"></div>
                           </div><br>

  <!-- Green -->               <label>skill</label>
                               <div class="progress">
                            <div class="progress-bar bg-success" style="width:20%"></div>
                              </div><br>

                   </div>
                      </div>
                      <div class="col-md-6">
                        <div class="progress_bar_graph">
                     
                          <label>skill</label>                    
                         <div class="progress">
                        <div class="progress-bar" style="width:10%"></div>
                           </div><br>

  <!-- Green -->               <label>skill</label>
                               <div class="progress">
                            <div class="progress-bar bg-success" style="width:60%"></div>
                              </div><br>

                   </div>
                      </div>
                    </div>

                       <div class="score_home"><button class="btn btn-primary">Home</button>  </div>                  
                      </div>
                      
                    
                      
                    
                  </div>
                </div>
                
              </div>
            <!-- </div>
            </div>
        </div> -->



     </div>



  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script type="text/javascript">
  	let menubar = document.querySelector('#menubar');
  	let menu_btn = document.querySelector('#menu_btn');
  	let top_navigation = document.querySelector('.top_navigation');
  	menu_btn.onclick = function () {
  		console.log(menubar);
  		 menubar.classList.toggle('active');
  		 top_navigation.classList.toggle('active');
  	}
  </script>


  <script type="text/javascript">
    let basic_info_submit = document.querySelector('#basic_info_submit');
    let about_me_submit = document.querySelector('#about_me_submit');
    let first_basic_info = document.querySelector('#first_basic_info');
    let second_about_me = document.querySelector('#second_about_me');
    let third_qualification = document.querySelector('#third_qualification');
    let third_next = document.querySelector('#third_next');
    let fourth_qualification = document.querySelector('#fourth_qualification');
    let fouth_next = document.querySelector('#fouth_next');
    let add_skill = document.querySelector('#add_skill');
    let skill_next = document.querySelector('#skill_next');
    let Work_experience = document.querySelector('#Work_experience');
    let Work_next = document.querySelector('#Work_next');
    let Work_experience_dis = document.querySelector('#Work_experience_dis');
    let Work_dis_next = document.querySelector('#Work_dis_next');
    let certificate = document.querySelector('#certificate');
    let certificate_next = document.querySelector('#certificate_next');
    let certificate_dis = document.querySelector('#certificate_dis');
    let certificate_dis_next = document.querySelector('#certificate_dis_next');
    let project_paper = document.querySelector('#project_paper');
    let project_next = document.querySelector('#project_next');
    let project_paper_display = document.querySelector('#project_paper_display');
    let project_dis_next = document.querySelector('#project_dis_next');
    let achivements = document.querySelector('#achivements');
    let achivement_next = document.querySelector('#achivement_next');
    let achivement_dis = document.querySelector('#achivement_dis');
    let achivement_dis_next = document.querySelector('#achivement_dis_next');
    let social_profile = document.querySelector('#social_profile');
    let social_next = document.querySelector('#social_next');
    let t_c = document.querySelector('#t_c');
    let t_c_next = document.querySelector('#t_c_next');
    let statment_truth = document.querySelector('#statment_truth');  


    const allItems = document.querySelectorAll('.side_progressbar ul li a');

    t_c_next.onclick = function(){
      t_c.classList.add('sec_active');
      statment_truth.classList.add('active');
      allItems[10].classList.add('active');
    }

    social_next.onclick = function(){
      social_profile.classList.add('sec_active');
      t_c.classList.add('active');
      allItems[9].classList.add('active');
    }

    achivement_dis_next.onclick = function(){
      achivement_dis.classList.add('sec_active');
      social_profile.classList.add('active');
      allItems[8].classList.add('active');
    }


    achivement_next.onclick = function(){
      achivements.classList.add('sec_active');
      achivement_dis.classList.add('active');
      
    }

    project_dis_next.onclick = function(){
      project_paper_display.classList.add('sec_active');
      achivements.classList.add('active');
      allItems[7].classList.add('active');
    }

    project_next.onclick = function(){
      project_paper.classList.add('sec_active');
      project_paper_display.classList.add('active');
      
    }

    certificate_dis_next.onclick = function(){
      certificate_dis.classList.add('sec_active');
      project_paper.classList.add('active');
      allItems[6].classList.add('active');
    }

    certificate_next.onclick = function(){
      certificate.classList.toggle('sec_active');
      certificate_dis.classList.toggle('active');
      
    }


    Work_dis_next.onclick = function(){
      Work_experience_dis.classList.toggle('sec_active');
      certificate.classList.toggle('active');
      allItems[5].classList.add('active');
    }
     
     Work_next.onclick = function(){
      Work_experience.classList.toggle('sec_active');
      Work_experience_dis.classList.toggle('active');
      
    }

    skill_next.onclick = function(){
      add_skill.classList.toggle('sec_active');
      Work_experience.classList.toggle('active');
      allItems[4].classList.add('active');
    }



    fouth_next.onclick = function(){
      fourth_qualification.classList.toggle('sec_active');
      add_skill.classList.toggle('active');
      allItems[3].classList.add('active');
    }


    
    basic_info_submit.onclick = function basic_info_submit(){

     

      var formData = new FormData(basic_info);
    formData.append('action','basicinfo_form_data');
         $.ajax({
      url:'tprocess.php',
      type:'POST',
      data:formData,
      contentType:false,
      processData:false,
      success:function(result){
        console.log(result);

        if (result == "success") {

          console.log(result);

      first_basic_info.classList.toggle('active');
      second_about_me.classList.toggle('active');
      allItems[1].classList.add('active');
        }
        else if (result == "not the registered email") {
          alert("Not the Registeredd Email");
        }
        else if(result == "Required"){
          alert("Fill all the feild");
        }
        else if(result == "Already Registered"){
          alert("Already Filled");
          first_basic_info.classList.toggle('active');
      second_about_me.classList.toggle('active');
      allItems[1].classList.add('active');
        }

      }
     })



    }


    about_me_submit.onclick = function(){

      let aboutme = document.querySelector('#aboutme').value;

      aboutme = aboutme.match(/\w+/g);

      aboutme = aboutme.length;


      if (aboutme < 5) {
        alert("Minimum 50 words Required");
        return false;
      }



      var formData = new FormData(about_me_form);
    formData.append('action','about_me_form_data');
         $.ajax({
      url:'tprocess.php',
      type:'POST',
      data:formData,
      contentType:false,
      processData:false,
      success:function(result){
        console.log(result);

      }
     })


      second_about_me.classList.toggle('sec_active');
      third_qualification.classList.toggle('active');
      allItems[2].classList.add('active');
    }

    third_next.onclick = function(){
      third_qualification.classList.toggle('third_active');
      fourth_qualification.classList.toggle('active');

      let u_id = <?php echo $_SESSION['id']?>;
      var data = {u_id:u_id, action:"academic_dispay"};
        $.ajax({
           url:'tprocess.php',
           type:'POST',
           data:data,
           success:function(result){
             console.log(result);
             
      }
     })

      
    }
 


    function logout_process(){
      var data = {action:'logout'};
        $.ajax({
           url:'tprocess.php',
           type:'POST',
           data:data,
           success:function(result){
             console.log(result);
             if (result == 'success') {
                    window.location.replace("index.php");
                }
      }
     })
    }

  </script>


<!-- QUALIFICATION SCRIPT -->

<script type="text/javascript">
      
   function certificate_data(){

    var certificate_name = document.getElementById("certificate_name").value;
    var certificate_org = document.getElementById("org_name").value;
    var c_issued_yr = document.getElementById("issued_yr").value;
    var c_exp_yr = document.getElementById("exp_yr").value;
    var no_exp_date = document.getElementById("no_exp_date").value;

    if (certificate_name == "" || certificate_org == "") {
      alert("Certificate name And Organisation name required");
      return false;
    }
    // if (c_issued_yr > c_exp_yr) {
    //   alert("Certificate Issued Year Can not Be Greater Than Expired Year");
    //   return false;
    // }

    // if (no_exp_date.checked && c_exp_yr != "") {
      
    //   alert("Check The certificate Expiration");
    //   return false;
    // }

    var formData = new FormData(certificate_form);
    formData.append('action','certificate_form_data');
         $.ajax({
      url:'tprocess.php',
      type:'POST',
      data:formData,
      contentType:false,
      processData:false,
      success:function(result){
        console.log(result);

        // location.reload();
      }
     })



   }
   

  function academic_data(){
    

    var a = document.getElementById("edu_level").value;
    var b = document.getElementById("feild_study").value;
    var c = document.getElementById("degreee").value;
    var d = document.getElementById("university").value;
    var e = document.getElementById("form_year").value;
    var f = document.getElementById("to_year").value;

    var g = document.getElementById("grade").value;

    
    if (a ==  "no" || b == "no" || c == "no" || d == "no" || g == "no") {
      alert("complete all the feild");
      return false;
    }
      if(e>=f){
        alert("Check the year");
        return false;
      }
  

    var formData = new FormData(academic_form_f);
    formData.append('action','academic_form_data');
         $.ajax({
      url:'tprocess.php',
      type:'POST',
      data:formData,
      contentType:false,
      processData:false,
      success:function(result){
        console.log(result);

        // location.reload();
      }
     })
    
  }

  let my_score = document.querySelector('#my_score');

  my_score.onclick = function(){
    let u_id = <?php echo $_SESSION['id']?>;
    var data = {u_id:u_id, action:"academic_score"};
      $.ajax({
      url:'tprocess.php',
      type:'POST',
      data:data,
      success:function(result){
        console.log(result);

        alert("Your Academic Score is: "+result + "%");

        let qualification_progressbar  = document.querySelector('#qualification_progressbar');

        qualification_progressbar.style.width = result + "%";

        // location.reload();
      }
     })
  }

  // university list

  function uni_view(){
    $.ajax({
      url:'tprocess.php',
      type:'POST',
      data:{action:'uni_list'},
      success:function(result){
        // console.log(result);
        var data = JSON.parse(result);
         // console.log(data);
         // return false;
        let tag = '<option value="no">University</option>';
        for(let i=0;i<data.length;i++){
          tag += '<option value="'+data[i]["uni_name"]+'">'+data[i]["uni_name"]+'</option>';
          // console.log(tag);
        }
        // console.log(tag);
         document.getElementById('university').innerHTML = tag;
      }
    })
  }
  $(function(){
    uni_view();
  });


</script>
<script src="js/sidebarscript.js"></script>


</body>
</html>

<?php
}
?>