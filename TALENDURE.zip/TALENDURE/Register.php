<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<title>Talendure</title>
	<link rel="stylesheet" type="text/css" href="style/style1.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
	<div class="main_container">
		<div class="top_nav">
			<div class="logo">
				<img src="image/logo.png">

			</div>
			
				<ul class="top_navigation">
					<li><a href="#">OUR STORY</a></li>
					<li><a href="#">INSIGHTS</a></li>
					<li><a href="#">GET IN TOUCH</a></li>
					<li><a href="login.php">Login</a></li>
				</ul>
		</div>

		<div class="container ">
			<div class="content_register">
				<h3>Let's Get Started</h3>
				<p>First Create talendure Account. Have an Account <a href="login.php">Login</a></p>
			</div>
				<form id="register_form" name="register_form">
            <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="edu_level">First Name<span class="mandetory">*</span></label>
                            <input type="text" class="form-control" name="fname" autocomplete="off" id="fname">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="feild_study">Last Name<span class="mandetory">*</span></label>
                            <input type="text" class="form-control" name="lname" autocomplete="off" id="lname">
                          </div>
                        </div>
              <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="degreee">Email<span class="mandetory">*</span></label>
                            <input type="email" class="form-control" name="email" id="e" autocomplete="off">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="university">Mobile<span class="mandetory">*</span></label>
                            <input type="text" class="form-control" name="mobile" autocomplete="off" id="mobile">
                          </div>
                        </div> 

              <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="degreee">Password<span class="mandetory">*</span></label>
                            <input type="password" class="form-control" name="password" autocomplete="off" id="pass">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="university">Conform Password<span class="mandetory">*</span></label>
                            <input type="password" class="form-control" name="cpassword" autocomplete="off" id="cpass">
                          </div>
                        </div> 
                        

            <button type="button" class="btn btn-warning" onclick="return register_data();" data-dismiss="modal">Register</button>
          </form>
		</div>
	</div>


  <script type="text/javascript">
    function register_data(){

      
  
            var email = document.getElementById("e").value;
            var email2 = document.getElementById("e");
            var fname = document.getElementById("fname").value;
            var fname2 = document.getElementById("fname");
            var lname = document.getElementById("lname").value;
            var lname2 = document.getElementById("lname");
            var mobile = document.getElementById("mobile").value;
            var mobile2 = document.getElementById("mobile");
            var pass = document.getElementById("pass").value;
            var pass2 = document.getElementById("pass");
            var cpass = document.getElementById("cpass").value;
            var cpass2 = document.getElementById("cpass");
            var emailrex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            var namerex = /^[a-zA-Z. ]{3,29}$/;
            var mobilerex = /^[0-9]{10}$/;
            var passrex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/;


            if (namerex.test(fname)) {
                
                fname2.style.border = "transparent solid 3px";
            }
            else {
                fname2.style.border = "#DE3E65 solid 3px";
                return false;
            }


            if (namerex.test(lname)) {
                lname2.style.border = "transparent solid 3px";
                
            }
            else {
                lname2.style.border = "#DE3E65 solid 3px";
                return false;
            }


            if (emailrex.test(email)) {
                email2.style.border = "transparent solid 3px";
                
            }
            else {
                email2.style.border = "#DE3E65 solid 3px";
                return false;
            }


            if (mobilerex.test(mobile)) {
                
                mobile2.style.border = "transparent solid 3px";
            }
            else {
                mobile2.style.border = "#DE3E65 solid 3px";
                return false;
            }


            if (pass == cpass) {
              if (passrex.test(pass)) {
                pass2.style.border = "transparent solid 3px";
                
            }
            else {
                pass2.style.border = "#DE3E65 solid 3px";
                return false;
            }


            if (passrex.test(cpass)) {
                cpass2.style.border = "transparent solid 3px";
                
            }
            else {
                cpass2.style.border = "#DE3E65 solid 3px";
                return false;
            }
            }

            else {
              pass2.style.border = "#DE3E65 solid 3px";
              cpass2.style.border = "#DE3E65 solid 3px";
              alert("password And Conform Password must be same");

              return false;
            }


            







      var formData = new FormData(register_form);
    formData.append('action','register_form_data');
         $.ajax({
      url:'tprocess.php',
      type:'POST',
      data:formData,
      contentType:false,
      processData:false,
      success:function(result){
        console.log(result);

        if (result == "success") {
          alert("Successfully Created your Account");
          window.location.replace("login.php");
        }

        // location.reload();
      }
     })
    }
  </script>
</body>
</html>