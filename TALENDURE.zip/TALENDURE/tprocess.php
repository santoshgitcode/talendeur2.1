<?php
  include 'connection.php';

  session_start();
  if (isset($_POST['action'])) {
  	if ($_POST['action'] == "register_form_data") {
  		$fanme = $_POST['fname'];
  		$lname = $_POST['lname'];
  		$email = $_POST['email'];
  		$mobile = $_POST['mobile'];
  		$password = $_POST['password'];
  		$cpassword = $_POST['cpassword'];

  		// echo $fanme." ".$lname." ".$email." ".$mobile." ".$password." ".$cpassword;

  		$queryemail = "select * from register where (email = '$email')";
		$exe = mysqli_query($con,$queryemail);
		$rows = mysqli_num_rows($exe);
		 // echo "$rows";
		 // exit();
         if ($rows > 0) {
         	echo "User Already Registered";
         }
         else{
		$query = "insert into register (fname,lname,email,mobile,pass,cpass) values ('$fanme','$lname','$email','$mobile','$password','$cpassword')";
		$res = mysqli_query($con,$query);
		if ($res) {
			echo "success";
		}
		else{
			echo "no";
		}
	}
  	}

  	if ($_POST['action'] == "login_form_data") {
  		

  		$email = $_POST["email"];
	    $password = $_POST["password"];


	    $emailquery = "select * from register where email = '$email'";

	$emailrun = mysqli_query($con,$emailquery);

	$rowdata = mysqli_fetch_array($emailrun);
	$existpass = $rowdata['pass'];
	$existemail = $rowdata['email'];

	$_SESSION["id"] = $rowdata['id'];

	 $_SESSION["fname"] = $rowdata['fname'];



	 if (($email === $existemail) && ($password === $existpass)) {
	 	

	 	echo "success";
	 }
	 else{
	 	echo "fiailed";
	 }

  	}


  	if ($_POST['action'] == "logout") {
  		session_destroy();
		echo "success";
  	}


  	if ($_POST['action'] == "basicinfo_form_data") {
  		$u_id = $_POST['user_id'];
  		$fanme = $_POST['fname'];
  		$lname = $_POST['lname'];
  		$dob = $_POST['dob'];
  		$email = $_POST['email'];
  		$mobile = $_POST['mobile'];
  		$add_one = $_POST['add_one'];
  		$add_two = $_POST['add_two'];
  		$city = $_POST['city'];
  		$state = $_POST['state'];
  		$zip = $_POST['zip'];
       

       if ($fanme == "" || $dob == "" || $mobile == ""|| $add_one == "" || $city == "" || $state == "" || $zip == "" ) {
       	echo "Required";
       }
       else{



  		$emailcheck = "select * from register where id = '$u_id'";
  		$execheck = mysqli_query($con,$emailcheck);

  		$exedata = mysqli_fetch_array($execheck);
  		$checkemail = $exedata['email'];


		  $rowcheck = mysqli_num_rows($execheck);

		  if ($checkemail == $email) {
		  	$queryemail = "select * from basic_info where (email = '$email')";
		$exe = mysqli_query($con,$queryemail);
		$rows = mysqli_num_rows($exe);
		 // echo "$rows";
		 // exit();
         if ($rows > 0) {
         	echo "Already Registered";
         }
         else{
		$query = "insert into basic_info (user_id,fname,lname,dob,email,mobile,add_one,add_two,city,state,zip) values ('$u_id','$fanme','$lname','$dob','$email','$mobile','$add_one','$add_two','$city','$state','$zip')";
		$res = mysqli_query($con,$query);
		if ($res) {
			echo "success";
		}
		else{
			echo "no";
		}
	}
		  	
		  }


		  else {
		  	echo "not the registered email";
		  }

  		}




  	}


  	if ($_POST['action'] == "about_me_form_data") {
  		$u_id = $_POST['user_id'];
  		$aboutme = $_POST['aboutme'];


  		$queryid = "select * from aboutme where (user_id = '$u_id')";
		$exe = mysqli_query($con,$queryid);
		$rows = mysqli_num_rows($exe);

		if ($rows > 0) {
			echo "Already Filled";
		}
		else{
			$query = "insert into aboutme (user_id,about_me) values ('$u_id','$aboutme')";
		$res = mysqli_query($con,$query);
		if ($res) {
			echo "success";
		}
		else{
			echo "no";
		}
		}

  	}


  	///academic Form Insert

  	if($_POST['action'] == "academic_form_data"){
  		$u_id = $_POST['user_id'];
       $edu_level = $_POST['edu_level'];
       $field_study = $_POST['field_study'];
       $degree = $_POST['degree'];
       $university = $_POST['university'];
       $grade = $_POST['grade'];
       $form_month = $_POST['form_month'];
       $form_year = $_POST['form_year'];
       $to_month = $_POST['to_month'];
       $to_year = $_POST['to_year'];


        	$queryid = "select * from academic where (u_id = '$u_id')";
		$exe = mysqli_query($con,$queryid);
		$rows = mysqli_num_rows($exe);

		if ($rows > 0) {
			echo "Already Filled";
		}

       else{

       $aca_insert_query = "insert into academic (u_id,edu_level,field_study,degree,university,grade,form_month,form_year,to_month,to_year) values ('$u_id','$edu_level','$field_study','$degree','$university','$grade','$form_month','$form_year','$to_month','$to_year')";

       $aca_query_run = mysqli_query($con,$aca_insert_query);

       if ($aca_query_run) {
         echo "success";
       }
       else{
        echo "Some Problem Occured";
       }
     }
    }

    if($_POST['action'] == "academic_score"){
    	$u_id = $_POST['u_id'];

    	$queryid = "select * from academic where (u_id = '$u_id')";
		  $exe = mysqli_query($con,$queryid);
		  $res = mysqli_fetch_array($exe);

		  $edu_level = $res['edu_level'];
		  $university = $res['university'];
		  $grade = $res['grade'];

		    // echo $edu_level." ".$grade." ".$university;
		    // exit();

		  $edu_level_value = "select * from edu_level where (eduLevel = '$edu_level')";

		  $edu_exe = mysqli_query($con,$edu_level_value);
		  $res_edu_value = mysqli_fetch_array($edu_exe);

		  $edu_level_value_act = $res_edu_value['value'];

		  // echo $edu_level_value_act;
		  // exit();

		   $grade_value = "select * from grade where (grade = '$grade')";

		   $grade_exe = mysqli_query($con,$grade_value);
		   $res_grade_value = mysqli_fetch_array($grade_exe);

		   $grade_value_act = $res_grade_value['value'];

		  //  echo $grade_value_act;
		  // exit();


		  $uni_type = "select * from university where (uni_name = '$university')";

		  $uni_type_exe = mysqli_query($con,$uni_type);
		  $res_uni_type = mysqli_fetch_array($uni_type_exe);

		  $uni_type_act = $res_uni_type['u_type'];

		  $uni_value = "select * from uni_type where (u_type = '$uni_type_act')";
		  $uni_exe = mysqli_query($con,$uni_value);
		  $res_uni_val = mysqli_fetch_array($uni_exe);

		  $uni_val_act = $res_uni_val['value'];

		   // echo $uni_val_act;
		   // exit();

		  $aca_value_act = $edu_level_value_act+$grade_value_act+$uni_val_act;

		    echo $aca_value_act;


    }

  	// end of isset
  }
?>