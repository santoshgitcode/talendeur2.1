<!DOCTYPE html>
<html lang="en">
<head>
  <title>Academic Score</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <style type="text/css">
    .main_div{
      display: flex;
      justify-content: center;
      align-items: center;
      background: rgba(0, 0, 0, 0.05);
      min-height: 100vh;
    }
    .center_div{
      position: relative;
      width: 60vw;
      height: 50vh;
      background: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.10);
      padding: 20px;
    }
    p{
      color: #ccc;
      font-size: 12px;
    }
    .btnBx{
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .btn_academic{
      border: none;
      outline: none;
      border-radius: 50%;
    }
    .mandetory{
      color: #f00;
    }
  </style>
</head>
<body>

<div class="container-fluid main_div">
  <div class="center_div">
    <div class="content">
      <div class="bsic_info">
                      <i class="fa fa-info-circle"></i> <p class="bsic_info_para">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.ut aliquip ex ea commodo consequat.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>

                      <div class="btnBx">
                        <button type="button" data-toggle="modal" data-target="#academic_modal" class="btn_academic"><i class="fa fa-plus"></i></button>
                      </div>
                    </div>

        <div class="score">
          <h2 id="score"></h2>
        </div>            
    </div>
  </div>

  <div class="modal fade" id="academic_modal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        
        <!-- Modal body -->
        <div class="modal-body">
          <form id="academic_form" name="academic_form">
            <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="edu_level">Educational Level<span class="mandetory">*</span></label>
                            <select id="edu_level" name="edu_level" class="form-control">
                              <option value="no">Select Educational Level</option>
                            </select>
                          </div>
                          <div class="form-group col-md-6">
                            <label for="feild_study">Field Of Study<span class="mandetory">*</span></label>
                            <select id="feild_study" class="form-control" name="field_study">
                              <option value="no">Select Field of study</option>
                            </select>
                          </div>
                        </div>
              <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="degreee">Degree<span class="mandetory">*</span></label>
                            <select id="degreee" class="form-control" name="degree">
                              <option value="no">Degree</option>
                            </select>
                          </div>
                          <div class="form-group col-md-6">
                            <label for="university">College/University<span class="mandetory">*</span></label>
                            <select id="university" class="form-control" name="university">
                              <option value="no">University</option>
                            </select>
                          </div>
                        </div> 


                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <label for="month">Form<span class="mandetory">*</span></label>
                            <select id="month" class="form-control col-5" name="form_month">
                              <option value="jan">Jan</option>
                              <option value="feb">Feb</option>
                              <option value="mar">Mar</option>
                              <option value="april">April</option>
                              <option value="may">May</option>
                              <option value="jun">Jun</option>
                              <option value="jul">Jul</option>
                              <option value="aug">Aug</option>
                              <option value="sep">Sep</option>
                              <option value="oct">Oct</option>
                              <option value="nov">Nov</option>
                              <option value="dec">Dec</option>
                            </select>
                            <select id="form_year" class="form-control col-5" name="form_year">
                              <option value="1980">1980</option>
                              <option value="1981">1981</option>
                              <option value="1982">1982</option>
                              <option value="1983">1983</option>
                              <option value="1984">1984</option>
                              <option value="1985">1985</option>
                              <option value="1986">1986</option>
                              <option value="1987">1987</option>
                              <option value="1988">1988</option>
                              <option value="1989">1989</option>
                              <option value="1990">1990</option>
                              <option value="1991">1991</option>
                              <option value="1992">1992</option>
                              <option value="1993">1993</option>
                              <option value="1994">1994</option>
                              <option value="1995">1995</option>
                              <option value="1996">1996</option>
                              <option value="1997">1997</option>
                              <option value="1998">1998</option>
                              <option value="1999">1999</option>
                              <option value="2000">2000</option>
                              <option value="2001">2001</option>
                              <option value="2002">2002</option>
                              <option value="2003">2003</option>
                              <option value="2004">2004</option>
                              <option value="2005">2005</option>
                              <option value="2006">2006</option>
                              <option value="2007">2007</option>
                              <option value="2008">2008</option>
                              <option value="2009">2009</option>
                              <option value="2010">2010</option>
                              <option value="2011">2011</option>
                              <option value="2012">2012</option>
                              <option value="2013">2013</option>
                              <option value="2014">2014</option>
                              <option value="2015">2015</option>
                              <option value="2016">2016</option>
                              <option value="2017">2017</option>
                              <option value="2018">2018</option>
                              <option value="2019">2019</option>
                              <option value="2020">2020</option>
                              <option value="2021">2021</option>
                              <option value="2022">2022</option>
                            </select>

                          </div>
                          <div class="form-group col-md-6">
                            <label for="month">To<span class="mandetory">*</span></label>
                            <select id="month" class="form-control col-5" name="to_month">
                              <option value="jan">Jan</option>
                              <option value="feb">Feb</option>
                              <option value="mar">Mar</option>
                              <option value="april">April</option>
                              <option value="may">May</option>
                              <option value="jun">Jun</option>
                              <option value="jul">Jul</option>
                              <option value="aug">Aug</option>
                              <option value="sep">Sep</option>
                              <option value="oct">Oct</option>
                              <option value="nov">Nov</option>
                              <option value="dec">Dec</option>
                            </select>
                             <select id="to_year" class="form-control col-5" name="to_year">
                              <option value="1980">1980</option>
                              <option value="1981">1981</option>
                              <option value="1982">1982</option>
                              <option value="1983">1983</option>
                              <option value="1984">1984</option>
                              <option value="1985">1985</option>
                              <option value="1986">1986</option>
                              <option value="1987">1987</option>
                              <option value="1988">1988</option>
                              <option value="1989">1989</option>
                              <option value="1990">1990</option>
                              <option value="1991">1991</option>
                              <option value="1992">1992</option>
                              <option value="1993">1993</option>
                              <option value="1994">1994</option>
                              <option value="1995">1995</option>
                              <option value="1996">1996</option>
                              <option value="1997">1997</option>
                              <option value="1998">1998</option>
                              <option value="1999">1999</option>
                              <option value="2000">2000</option>
                              <option value="2001">2001</option>
                              <option value="2002">2002</option>
                              <option value="2003">2003</option>
                              <option value="2004">2004</option>
                              <option value="2005">2005</option>
                              <option value="2006">2006</option>
                              <option value="2007">2007</option>
                              <option value="2008">2008</option>
                              <option value="2009">2009</option>
                              <option value="2010">2010</option>
                              <option value="2011">2011</option>
                              <option value="2012">2012</option>
                              <option value="2013">2013</option>
                              <option value="2014">2014</option>
                              <option value="2015">2015</option>
                              <option value="2016">2016</option>
                              <option value="2017">2017</option>
                              <option value="2018">2018</option>
                              <option value="2019">2019</option>
                              <option value="2020">2020</option>
                              <option value="2021">2021</option>
                              <option value="2022">2022</option>
                            </select>
                          </div>
                        </div> 
                        

            <button type="button" class="btn btn-success" onclick="return academic_data();">Submit</button>
            <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
          </form>
        </div>
        
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
      
     

  $(document).ready(function(){
    function loadData(type,category_id){
      $.ajax({
        url:'acaprocess.php',
        type:'POST',
        data : {type:type, id:category_id},
        success: function(result){
          // console.log(result);
          if(type == "feild_study"){
            $('#feild_study').append(result);
          }
         else if(type == "degree"){
            // console.log(result);
            $('#degreee').append(result);
          }
         else if(type == "university") {
            // console.log(result);
            $('#university').append(result);
          }
          else{
          $('#edu_level').append(result);
        }
        }
      })
    }
    loadData();


    $('#edu_level').on('change', function(){
      loadData("feild_study");
    })

    $('#feild_study').on('change', function(){
      var feild_id = $("#feild_study").val();
      loadData("degree",feild_id);
    })



    $('#degreee').on('change', function(){
      var deg_id = $("#degreee").val();
      // console.log(deg_id);
      loadData("university",deg_id);
    })

  })


  function academic_data(){
    

    var a = document.getElementById("edu_level").value;
    var b = document.getElementById("feild_study").value;
    var c = document.getElementById("degreee").value;
    var d = document.getElementById("university").value;
    var e = document.getElementById("form_year").value;
    var f = document.getElementById("to_year").value;

    
    if (a ==  "no" || b == "no" || c == "no" || d == "no") {
      alert("complete all the feild");
      return false;
    }
    else {
      if(e >= f){
        alert("Check the year");
        return false;
      }
      else{

        console.log(e+" "+f);
      }
    }

    var formData = new FormData(academic_form);
    formData.append('action','academic_form_data');
         $.ajax({
      url:'acaprocess_two.php',
      type:'POST',
      data:formData,
      contentType:false,
      processData:false,
      success:function(result){
        console.log(result);

        // location.reload();
      }
     })
    
  }


</script>

</body>
</html>